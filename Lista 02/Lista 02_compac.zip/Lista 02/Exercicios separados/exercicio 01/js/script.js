function idade(){
    var anos= parseInt(prompt("Digite a idade em anos: "))
    var meses= parseInt(prompt("Digite os meses: "))
    var dias= parseInt(prompt("Digite os dias: "))
    var idade=alert((anos*360)+(meses*30)+dias)
    alert("Ao todo são: ");
}

