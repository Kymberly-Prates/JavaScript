
function calcular(){
    var fahrenheit = parseInt(document.getElementById("fahrenheit").value);
    calculo.value =(((9*fahrenheit)+160)/5);   
}

