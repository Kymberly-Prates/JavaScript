function calcular(){
    var celcius = parseInt(document.getElementById("celcius").value);
    calculo.value =(celcius-32) *(5/9);   
}

