function calcular(){
    var altura = parseInt(document.getElementById("altura").value);
    var raio = parseInt(document.getElementById("raio").value);
    calculo.value =(3.14*(raio*raio)*altura);   
}


