function calculoa(){
    var a = parseInt(document.getElementById("a").value);
    var b = parseInt(document.getElementById("b").value);
    var c = parseInt(document.getElementById("c").value);
    calculandoa.value =(a=b)
}

function calculob(){
    var c = parseInt(document.getElementById("a").value);
    var b = parseInt(document.getElementById("b").value);
    calculandoa.value =(b=c)
}

