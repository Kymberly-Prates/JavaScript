function calcular1(){
    var nulos = parseInt(document.getElementById("nulos").value);
    var brancos = parseInt(document.getElementById("brancos").value);
    var validos = parseInt(document.getElementById("validos").value);

    calculonulos.value =(nulos/100);
}

function calcular2(){
    var nulos = parseInt(document.getElementById("nulos").value);
    var brancos = parseInt(document.getElementById("brancos").value);
    var validos = parseInt(document.getElementById("validos").value);

    calculobrancos.value =(brancos/100);  
    
}

function calcular3(){
    var nulos = parseInt(document.getElementById("nulos").value);
    var brancos = parseInt(document.getElementById("brancos").value);
    var validos = parseInt(document.getElementById("validos").value);
   
    calculovalidos.value =(validos/100);   
}