
function calcular(){
    var carro = parseInt(document.getElementById("carro").value);
    var imposto = 45/100;
    var distribuidor = 28/100;
    calculo.value =(carro + imposto + distribuidor);   
}